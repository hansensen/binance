import json
import os
import pymysql

# Get database info from environment variables
db_host = os.environ['DB_HOST']
db_user = os.environ['DB_USER']
db_password = os.environ['DB_PASSWORD']
db_name = os.environ['DB_NAME']

def lambda_handler(event, context):

    # Log the received event
    print("Received event: " + json.dumps(event, indent=2))

    for record in event['Records']:
        # Only process 'INSERT' events (i.e., new records added to the table)
        if record['eventName'] == 'INSERT':
            new_image = record['dynamodb']['NewImage']
            position = new_image['position']['S']

            # Proceed only if the position is NEUTRAL
            if position == 'NEUTRAL':
                # Extract the relevant information from the new image
                # DynamoDB Streams encode numbers as strings; convert as necessary
                timestamp = new_image['timestamp']['N']
                accumulated_gain = float(new_image['accumulated_gain']['N'])

                # Log the extracted information
                print(f"Timestamp: {timestamp}, Accumulated Gain: {accumulated_gain}")
                
                # Additional processing for NEUTRAL position records could be done here
                # For example: sending this information to an S3 bucket or a notification system

    connection = pymysql.connect(host=db_host, user=db_user, password=db_password, db=db_name)

    try:
        # Example of inserting data into a table
        with connection.cursor() as cursor:
            sql = "INSERT INTO your_table_name (column1, column2) VALUES (%s, %s)"
            cursor.execute(sql, ('data1', 'data2'))
            
        # Commit the changes
        connection.commit()
    finally:
        # Close the connection
        connection.close()

    return {
        'statusCode': 200,
        'body': json.dumps('Successfully inserted data into RDS MySQL database and successfully processed DynamoDB stream records.')
    }
